﻿using BOnlineStore.Shared.Entities;
using MongoDB.Bson;

namespace $rootnamespace$
{
    public class $safeitemname$ : Entity
    {
        public string Code { get; private set; }
        public string Name { get; private set; }

        public $safeitemname$() : base()
        {
            Code = "";
            Name = "";
        }

        public $safeitemname$(Guid tenantId, string id, string code, string name) : base(tenantId, id)
        {
            Code = code;
            Name = name;
        }

        public void Update$safeitemname$(string code, string name)
        {
            Code = code;
            Name = name;
        }
    }
}
