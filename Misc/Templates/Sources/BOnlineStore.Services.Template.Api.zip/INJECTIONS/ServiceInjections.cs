﻿namespace $safeprojectname$.Injections
{
    public static partial class Injections
    {
        public static IServiceCollection AddServiceInjections(this IServiceCollection services)
        {
            return services;
        }
    }
}
