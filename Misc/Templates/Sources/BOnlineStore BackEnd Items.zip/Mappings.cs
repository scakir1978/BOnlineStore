﻿using AutoMapper;
using BOnlineStore.Services.Definitions.Api.Dtos;
using BOnlineStore.Services.Definitions.Api.Entities;

namespace $rootnamespace$
{
    public class $className$Mappings
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<$className$, $className$Dto>().DisableCtorValidation().ReverseMap().DisableCtorValidation();
                config.CreateMap<$className$, $className$CreateDto>().DisableCtorValidation().ReverseMap().DisableCtorValidation();
                config.CreateMap<$className$, $className$UpdateDto>().DisableCtorValidation().ReverseMap().DisableCtorValidation().ForAllMembers(opts => opts.Condition((src, dest, srcMember) => srcMember != null));

            });

            return mappingConfig;
        }
    }
}
