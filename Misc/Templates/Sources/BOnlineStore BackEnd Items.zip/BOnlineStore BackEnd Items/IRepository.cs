﻿using BOnlineStore.MongoDb.GenericRepository;
using $rootnamespace$.Entities;

namespace $rootnamespace$.Repositories
{
    public interface I$className$Repository : IRepository<$className$>
    {
    }
}
