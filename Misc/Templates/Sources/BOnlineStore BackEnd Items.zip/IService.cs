﻿using BOnlineStore.Generic.Service;
using BOnlineStore.Services.Definitions.Api.Dtos;
using BOnlineStore.Services.Definitions.Api.Entities;
using System.Linq.Expressions;

namespace $rootnamespace$.Services
{
    public interface I$className$Service : IService<$className$, $className$Dto, $className$CreateDto, $className$UpdateDto>
    {
    }
}
